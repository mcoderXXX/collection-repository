======================
Extreme Sports addon for Kodi
======================

About
-----
Extreme Sports Channel: The Home of Action Sports

Kodi Addon for http://extreme.com

This addon is not published nor endorsed by extreme.com


Artwork
---------------------
Artwork sourced from public domain:

http://logos.wikia.com/wiki/Extreme_Sports_Channel?file=EXTREME_SPORT_CHANNEL_HD.png


License
-------
This software is released under the [GPL 3.0 license] [1].

[1]: http://www.gnu.org/licenses/gpl-3.0.html