import xbmcaddon

MainBase = 'https://goo.gl/91HBVG'
addon = xbmcaddon.Addon('plugin.video.jico')